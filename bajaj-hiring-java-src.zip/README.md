# Bajaj Finserv Health - Qualifier 1 (Java)

This project contains a Spring Boot application that, on startup, contacts the assignment API to obtain a webhook and access token, then submits the final SQL query automatically.

## Files included
- `src/main/java/com/example/bajaj/*` - Java source files
- `src/main/resources/application.properties` - configuration (edit before build)
- `pom.xml` - Maven project file

## Build
1. Ensure JDK 17 and Maven are installed.
2. Edit `src/main/resources/application.properties` and paste your final SQL into `hiring.final.query`.
3. Run: `mvn clean package`
4. The JAR will be created at `target/bajaj-hiring-java-1.0.0.jar`

## How to publish JAR to GitHub Releases
1. Create a GitHub repo and push this project.
2. In GitHub, go to "Releases" → "Draft a new release" → upload the JAR file from `target/`.
3. After publishing the release, the downloadable release URL will be:
   `https://github.com/<username>/<repo>/releases/download/<tag>/bajaj-hiring-java-1.0.0.jar`
